﻿using System;
using PresentationLayer;
namespace Work
{
    class Program
    {
        static void Main(string[] args)
        {
            Menu.Run();
        }
    }
}
