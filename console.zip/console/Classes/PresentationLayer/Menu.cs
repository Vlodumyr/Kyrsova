﻿using System;
using BusinessLayer;
using System.Collections.Generic;

namespace PresentationLayer
{
    public class Menu
    {
        public static void printPublciationListWithAvailability(List<Publication> publications_list)
        {
            if (publications_list.Count == 0)
            {                
                Console.WriteLine("There is no publications with such parameters.");                
            }
            else
            {
                Console.WriteLine("ID   Title                          Author                Publication type  In Library");
                foreach (var item in publications_list)
                {
                    Console.WriteLine(item.toAvailableSring());
                }
                Console.WriteLine("Press any button to continue");
                Console.ReadLine();
            }
            
        }
        public static void printList<T>(List<T> list, bool show_publication_availability=false)
        {
            if (list.Count == 0)
            {
                if (typeof(T).Name == "User")
                {                    
                    throw new ArgumentNullException("There is no users with such parameters.");
                }
                if (typeof(T).Name == "Publication")
                {
                    throw new ArgumentNullException("There is no publications with such parameters.");
                }
                
            }
            else
            {
                if (typeof(T).Name == "User")
                {
                    Console.WriteLine("ID   First name     Last name        PassportId Age  Academic group Issued publications");
                }
                if (typeof(T).Name == "Publication")
                { 
                    Console.WriteLine("ID   Title                          Author                    Publication type");
                }
                foreach (var item in list)
                {
                        Console.WriteLine(item);
                                
                }
            }
            
            Console.WriteLine("Press any button to continue");
            Console.ReadLine();
        }
        public static void Run() 
        {
            EntityService entityService = new EntityService();
            bool flag = true;
            while (flag)
            {
                Console.Clear();
                Console.WriteLine("Select what you want to do");
                Console.WriteLine("1 - Work with users");
                Console.WriteLine("2 - Work with publications");
                Console.WriteLine("3 - Recieve or return book");
                Console.WriteLine("4 - End program");
                int menu_choice = 0;
                try
                {
                    menu_choice = Int32.Parse(Console.ReadLine());
                }
                catch (FormatException e)
                {
                    Console.WriteLine("Please enter valid data. Press any button to contienue");
                    Console.ReadLine();
                    continue;
                }
                switch (menu_choice)
                {
                    case 1:
                        {
                            Console.Clear();
                            Console.WriteLine("You are working with users. Select what you want to do");
                            Console.WriteLine("1 - Create new user");
                            Console.WriteLine("2 - Sort users");
                            Console.WriteLine("3 - Show all users");
                            Console.WriteLine("4 - Search through all users");
                            Console.WriteLine("5 - Go to the main menu");
                            int case1_choice = 0;
                            try
                            {
                                 case1_choice = Int32.Parse(Console.ReadLine());
                            }
                            catch (FormatException e)
                            {
                                Console.WriteLine("Please enter valid data. Press any key to continue");
                                Console.ReadLine();
                                continue;
                            }
                            Console.Clear();
                            switch (case1_choice)
                            {
                                case 1:
                                    {
                                        bool create_user_flag = true;
                                        while (create_user_flag)
                                        {
                                            Console.Clear();
                                            Console.WriteLine("You are creating new user");
                                            Console.WriteLine("Enter user's first name");
                                            string first_name = Console.ReadLine();
                                            Console.WriteLine("Enter user's last name");
                                            string last_name = Console.ReadLine();
                                            Console.WriteLine("Enter user's age");
                                            int age = 0;
                                            try
                                            {
                                                 age = Int32.Parse(Console.ReadLine());
                                            }
                                            catch (FormatException e)
                                            {
                                                Console.WriteLine("Please enter valid data. Press any button contienue.");
                                                Console.ReadLine();
                                                continue;

                                            }
                                            Console.WriteLine("Enter user's passport ID ");
                                            string passportId = Console.ReadLine();
                                            Console.WriteLine("Enter user's academy group");
                                            Console.WriteLine("1 - if user is scientist");
                                            Console.WriteLine("2 - if user is student");
                                            Console.WriteLine("3 - if none of this");
                                            int academy_group_choice = Int32.Parse(Console.ReadLine());
                                            string academy_group = "user";
                                            switch (academy_group_choice)
                                            {
                                                case 1:
                                                    {
                                                        academy_group = "scientist";
                                                        break;
                                                    }
                                                case 2:
                                                    {
                                                        academy_group = "student";
                                                        break;
                                                    }
                                                case 3:
                                                    {
                                                        academy_group = "user";
                                                        break;
                                                    }
                                            }
                                            try
                                            {
                                                User user = new User(first_name, last_name, age, passportId, academy_group,false);
                                                create_user_flag = false;
                                                entityService.AddUser(user);
                                            }
                                            catch (ArgumentException e)
                                            {
                                                Console.WriteLine(e.Message);
                                                Console.ReadLine();
                                                continue;
                                            }
                                        }                                     
                                        break;
                                    }
                                case 2:
                                    {

                                        Console.WriteLine("Select how to sort users");
                                        Console.WriteLine("1 - By first name");
                                        Console.WriteLine("2 - By last name");
                                        Console.WriteLine("3 - By academic group");
                                        int sort_choice = 0;
                                        try
                                        {
                                            sort_choice = Int32.Parse(Console.ReadLine());
                                        }
                                        catch (FormatException e)
                                        {
                                            Console.WriteLine("Please enter valid data. Press any button to contienue");
                                            Console.ReadLine();
                                        }
                                        if (sort_choice == 1)
                                        {
                                            printList<User>(entityService.UsersSortByFirstName());
                                        }
                                        if (sort_choice == 2)
                                        {
                                            printList<User>(entityService.UsersSortByLastName());
                                        }
                                        if (sort_choice == 3)
                                        {
                                            printList<User>(entityService.UsersSortByAcademicGroup());
                                        }
                                        break;
                                    }
                                case 3:
                                    {
                                        Console.WriteLine("List of all users");
                                        printList<User>(entityService.UsersList);
                                        break;
                                    }
                                case 4:
                                    {
                                        while (true)
                                        {
                                            Console.Clear();
                                            Console.WriteLine("Choose what parameter you wanna search by");
                                            Console.WriteLine("1 - Name");
                                            Console.WriteLine("2 - Passport ID");
                                            Console.WriteLine("3 - Go to the main menu");
                                            int user_search_choice = 0;
                                            try
                                            {
                                                 user_search_choice = Int32.Parse(Console.ReadLine());
                                            }
                                            catch (FormatException e)
                                            {
                                                Console.WriteLine("Please enter valid data. Press any button to continue");
                                                Console.ReadLine();
                                                continue;
                                            }
                                            if (user_search_choice == 1)
                                            {
                                                
                                                Console.WriteLine("Type name or part of name to find");
                                                string piece_of_name_to_find = Console.ReadLine();
                                                try
                                                {
                                                    printList<User>(entityService.UsersSearchByName(piece_of_name_to_find));

                                                }
                                                catch (ArgumentNullException e)
                                                {
                                                    Console.WriteLine(e.Message + "Press any button to continue");
                                                    Console.ReadLine();
                                                    break;

                                                }
                                                if (entityService.UsersSearchByName(piece_of_name_to_find).Count != 0)
                                                {
                                                    Console.WriteLine("Type user id that you want to modify. Type 0 if you want to go back to menu");
                                                    int id = Int32.Parse(Console.ReadLine());
                                                    if (id != 0)
                                                    {
                                                        try
                                                        {
                                                            User user = entityService.GetUserById(id);
                                                            Console.WriteLine("You choose this user :");
                                                            Console.WriteLine(user);
                                                            Console.WriteLine("Select what you want to do");
                                                            Console.WriteLine("1 - Change users data");
                                                            Console.WriteLine("2 - Delete user");
                                                            Console.WriteLine("3 - Back to menu");
                                                            int user_choice = Int32.Parse(Console.ReadLine());
                                                            if (user_choice == 1)
                                                            {
                                                                bool user_change_flag = true;
                                                                while (user_change_flag)
                                                                {
                                                                    Console.WriteLine("Select which attibute you want to change");
                                                                    Console.WriteLine("1 - First name");
                                                                    Console.WriteLine("2 - Last name");
                                                                    Console.WriteLine("3 - Age");
                                                                    Console.WriteLine("4 - PassportID");
                                                                    Console.WriteLine("5 - Number of issured publications");
                                                                    int attribute_choice = Int32.Parse(Console.ReadLine());
                                                                    switch (attribute_choice)
                                                                    {
                                                                        case 1:
                                                                            {
                                                                                Console.WriteLine("Previous first name was: " + user.FirstName);
                                                                                Console.WriteLine("Enter new first name");
                                                                                string firstname = Console.ReadLine();
                                                                                try
                                                                                {
                                                                                    user.FirstName = firstname;
                                                                                    Console.WriteLine("Do you want to continue changing this user?");
                                                                                    Console.WriteLine("1- YES");
                                                                                    Console.WriteLine("2 - NO");
                                                                                    int continue_changing = Int32.Parse(Console.ReadLine());
                                                                                    if (continue_changing == 2)
                                                                                    {
                                                                                        user_change_flag = false;
                                                                                    }
                                                                                }
                                                                                catch (ArgumentException e)
                                                                                {
                                                                                    Console.WriteLine(e.Message);
                                                                                }


                                                                                break;
                                                                            }
                                                                        case 2:
                                                                            {
                                                                                Console.WriteLine("Previous last name was: " + user.LastName);
                                                                                Console.WriteLine("Enter new last name");
                                                                                string lastname = Console.ReadLine();
                                                                                try
                                                                                {
                                                                                    user.LastName = lastname;
                                                                                    Console.WriteLine("Do you want to continue changing this user?");
                                                                                    Console.WriteLine("1- YES");
                                                                                    Console.WriteLine("2 - NO");
                                                                                    int continue_changing = Int32.Parse(Console.ReadLine());
                                                                                    if (continue_changing == 2)
                                                                                    {
                                                                                        user_change_flag = false;
                                                                                    }
                                                                                }
                                                                                catch (ArgumentException e)
                                                                                {
                                                                                    Console.WriteLine(e.Message);
                                                                                }
                                                                                break;
                                                                            }
                                                                        case 3:
                                                                            {
                                                                                Console.WriteLine("Previous age was: " + user.Age);
                                                                                Console.WriteLine("Enter new age");
                                                                                int age = Int32.Parse(Console.ReadLine());
                                                                                try
                                                                                {
                                                                                    user.Age = age;
                                                                                    Console.WriteLine("Do you want to continue changing this user?");
                                                                                    Console.WriteLine("1- YES");
                                                                                    Console.WriteLine("2 - NO");
                                                                                    int continue_changing = Int32.Parse(Console.ReadLine());
                                                                                    if (continue_changing == 2)
                                                                                    {
                                                                                        user_change_flag = false;
                                                                                    }
                                                                                }
                                                                                catch (ArgumentException e)
                                                                                {
                                                                                    Console.WriteLine(e.Message + " Please press any key to continue");
                                                                                    Console.ReadLine();

                                                                                }
                                                                                break;
                                                                            }
                                                                        case 4:
                                                                            {
                                                                                Console.WriteLine("Previous Passport Id was: " + user.PassportId);
                                                                                Console.WriteLine("Enter new age");
                                                                                string passportId = Console.ReadLine();
                                                                                try
                                                                                {
                                                                                    user.PassportId = passportId;
                                                                                    Console.WriteLine("Do you want to continue changing this user?");
                                                                                    Console.WriteLine("1- YES");
                                                                                    Console.WriteLine("2 - NO");
                                                                                    int continue_changing = Int32.Parse(Console.ReadLine());
                                                                                    if (continue_changing == 2)
                                                                                    {
                                                                                        user_change_flag = false;
                                                                                    }
                                                                                }
                                                                                catch (ArgumentException e)
                                                                                {
                                                                                    Console.WriteLine(e.Message);
                                                                                }
                                                                                break;
                                                                            }
                                                                        case 5:
                                                                            {
                                                                                Console.WriteLine("Previous number of issued publications was: " + user.IssuedPublicationNumber);
                                                                                Console.WriteLine("Enter new number of issued publications");
                                                                                int issuedPublicationNumber = Int32.Parse(Console.ReadLine());
                                                                                try
                                                                                {
                                                                                    user.IssuedPublicationNumber = issuedPublicationNumber;
                                                                                    Console.WriteLine("Do you want to continue changing this user?");
                                                                                    Console.WriteLine("1- YES");
                                                                                    Console.WriteLine("2 - NO");
                                                                                    int continue_changing = Int32.Parse(Console.ReadLine());
                                                                                    if (continue_changing == 2)
                                                                                    {
                                                                                        user_change_flag = false;
                                                                                    }
                                                                                }
                                                                                catch (ArgumentException e)
                                                                                {
                                                                                    Console.WriteLine(e.Message + " Press any key to continue");
                                                                                    Console.ReadLine();
                                                                                }
                                                                                break;
                                                                            }
                                                                    }

                                                                }
                                                            }
                                                            if (user_choice == 2)
                                                            {
                                                                entityService.RemoveUserById(id);
                                                            }
                                                        }
                                                        catch (ArgumentNullException e)
                                                        {
                                                            Console.WriteLine(e.Message + " Please press any button to continue");
                                                            Console.ReadLine();
                                                        }
                                                        catch (FormatException e)
                                                        {
                                                            Console.WriteLine("Enter valid data.  Please press any button to continue");
                                                            Console.ReadLine();
                                                        }


                                                    }
                                                }
                                                else
                                                {
                                                    Console.WriteLine("There is no users with this name");
                                                }
                                                                                              
                                                break;
                                            }
                                            else if(user_search_choice==2)
                                            {
                                                Console.WriteLine("Type name or part of passport ID to find");
                                                string piece_of_password_to_find = Console.ReadLine();
                                                try
                                                {
                                                    printList<User>(entityService.UsersSearchByPassportID(piece_of_password_to_find));
                                                }
                                                catch (ArgumentNullException e)
                                                {
                                                    Console.WriteLine(e.Message + " Please press any button to continue");
                                                    Console.ReadLine();
                                                }
                                                break;
                                            }
                                            else
                                            {
                                                break;
                                            }
                                        }
                                        break;
                                    }
                                case 5:
                                    {
                                        break;
                                    }
                            }



                            break;
                        }
                  case 2:
                        {
                            Console.Clear();
                            Console.WriteLine("You are working with publications. Select what you want to do");
                            Console.WriteLine("1 - Create new publications");
                            Console.WriteLine("2 - Sort publications");
                            Console.WriteLine("3 - Show all publications");
                            Console.WriteLine("4 - Search through all publications");
                            Console.WriteLine("5 - Go to the main menu");
                            int case1_choice = Int32.Parse(Console.ReadLine());
                            switch (case1_choice)
                            {
                                case 1:
                                    {
                                        bool create_user_flag = true;
                                        while (create_user_flag)
                                        {
                                            Console.Clear();
                                            Console.WriteLine("You are creating new publication");
                                            Console.WriteLine("Enter publication title");
                                            string title = Console.ReadLine();
                                            Console.WriteLine("Enter publication author");
                                            string author = Console.ReadLine();
                                            Console.WriteLine("Enter type of the publication");
                                            Console.WriteLine("1 - Book");
                                            Console.WriteLine("2 - Document");
                                            int publication_type_choice = Int32.Parse(Console.ReadLine());
                                            string publication_type = "Book";
                                            switch (publication_type_choice)
                                            {
                                                case 1:
                                                    {
                                                        publication_type = "Book";
                                                        break;
                                                    }
                                                case 2:
                                                    {
                                                        publication_type = "Document";
                                                        break;
                                                    }                              
                                            }
                                            try
                                            {
                                                Publication publication = new Publication(title,author,publication_type, false);
                                                create_user_flag = false;
                                                entityService.AddPublication(publication);
                                            }
                                            catch (ArgumentException e)
                                            {
                                                Console.WriteLine(e.Message);
                                                continue;
                                            }
                                        }

                                        break;
                                    }
                                case 2:
                                    {
                                        Console.WriteLine("Select how to sort publications");
                                        Console.WriteLine("1 - By Title");
                                        Console.WriteLine("2 - By Author");
                                        int sort_choice = Int32.Parse(Console.ReadLine());
                                        if (sort_choice == 1)
                                        {
                                            printPublciationListWithAvailability(entityService.PublicationSortByTitle());
                                        }
                                        if (sort_choice == 2)
                                        {
                                            printPublciationListWithAvailability(entityService.PublicationSortByAuthor());
                                        }
                                                                              
                                        break;
                                    }
                                case 3:
                                    {
                                        Console.WriteLine("List of all publications");
                                        printPublciationListWithAvailability(entityService.PublicationsList);
                                        break;
                                    }
                                case 4:
                                    {
                                        while (true)
                                        {
                                            Console.WriteLine("Choose what parameter you wanna search by");
                                            Console.WriteLine("1 - Title");
                                            Console.WriteLine("2 - Key word");
                                            Console.WriteLine("3 - Go to the main menu");
                                            int user_search_choice = Int32.Parse(Console.ReadLine());
                                            if (user_search_choice == 1)
                                            {
                                                Console.WriteLine("Type title or part of title to find");
                                                string piece_of_title_to_find = Console.ReadLine();
                                                printPublciationListWithAvailability(entityService.PublicationSearchByTitle(piece_of_title_to_find));

                                                Console.WriteLine("Type publication id that you want to modify. Type 0 if you want to go back to menu");
                                                int id = Int32.Parse(Console.ReadLine());
                                                if (id != 0)
                                                {
                                                    Publication publication = entityService.GetPublicationById(id);
                                                    Console.WriteLine("You choose this publiction :");
                                                    Console.WriteLine(publication);
                                                    Console.WriteLine("Select what you want to do");
                                                    Console.WriteLine("1 - Change users data");
                                                    Console.WriteLine("2 - Delete user");
                                                    Console.WriteLine("3 - Back to menu");
                                                    int publication_choice = Int32.Parse(Console.ReadLine());
                                                    if (publication_choice == 1)
                                                    {
                                                        bool user_change_flag = true;
                                                        while (user_change_flag)
                                                        {
                                                            Console.WriteLine("Select which attibute you want to change");
                                                            Console.WriteLine("1 - Title");
                                                            Console.WriteLine("2 - Author");                                   
                                                            int attribute_choice = Int32.Parse(Console.ReadLine());
                                                            switch (attribute_choice)
                                                            {
                                                                case 1:
                                                                    {
                                                                        Console.WriteLine("Previous title was: " + publication.Title);
                                                                        Console.WriteLine("Enter new title");
                                                                        string title = Console.ReadLine();
                                                                        try
                                                                        {
                                                                            publication.Title = title;
                                                                            Console.WriteLine("Do you want to continue changing this user?");
                                                                            Console.WriteLine("1- YES");
                                                                            Console.WriteLine("2 - NO");
                                                                            int continue_changing = Int32.Parse(Console.ReadLine());
                                                                            if (continue_changing == 2)
                                                                            {
                                                                                user_change_flag = false;
                                                                            }
                                                                        }
                                                                        catch (ArgumentException e)
                                                                        {
                                                                            Console.WriteLine(e.Message);
                                                                        }


                                                                        break;
                                                                    }
                                                                case 2:
                                                                    {
                                                                        Console.WriteLine("Previous author was: " + publication.Author);
                                                                        Console.WriteLine("Enter new last name");
                                                                        string author = Console.ReadLine();
                                                                        try
                                                                        {
                                                                            publication.Author = author;
                                                                            Console.WriteLine("Do you want to continue changing this user?");
                                                                            Console.WriteLine("1- YES");
                                                                            Console.WriteLine("2 - NO");
                                                                            int continue_changing = Int32.Parse(Console.ReadLine());
                                                                            if (continue_changing == 2)
                                                                            {
                                                                                user_change_flag = false;
                                                                            }
                                                                        }
                                                                        catch (ArgumentException e)
                                                                        {
                                                                            Console.WriteLine(e.Message);
                                                                        }
                                                                        break;
                                                                    }                         
                                                            }

                                                        }
                                                    }
                                                }

                                                break;
                                            }
                                            else if (user_search_choice == 2)
                                            {
                                                Console.WriteLine("Type keyword to find");
                                                string piece_of_keyword = Console.ReadLine();
                                                printPublciationListWithAvailability(entityService.PublicationSearchByKeyWord(piece_of_keyword));
                                                break;
                                            }
                                            else
                                            {
                                                continue;
                                            }
                                        }
                                        break;
                                    }
                                case 5:
                                    {
                                        break;
                                    }
                            }
                            break;
                        }
                  case 3:
                        {
                            Console.WriteLine("Select what you want to do");
                            Console.WriteLine("1 -  Give book to user");
                            Console.WriteLine("2 -  Return book from user");
                            int action_choice = 0;
                            try
                            {
                                 action_choice = Int32.Parse(Console.ReadLine());
                            }
                            catch (FormatException e)
                            {
                                Console.WriteLine("Please enter valid data. Press any key to continue");
                                Console.ReadLine();
                                break;
                            }

                            Console.WriteLine("Choose what parameter you wanna search user  by");
                            Console.WriteLine("1 - Name");
                            Console.WriteLine("2 - Passport ID");
                            Console.WriteLine("3 - Go to the main menu");
                            int user_search_choice = 0;
                            try
                            {
                                 user_search_choice = Int32.Parse(Console.ReadLine());
                            }
                            catch (FormatException e)
                            {
                                Console.WriteLine("Please enter valid data. Press any key to continue");
                                Console.ReadLine();
                                break;
                            }
                            if (user_search_choice == 1)
                            {
                                Console.WriteLine("Type name or part of name to find");
                                string piece_of_name_to_find = Console.ReadLine();
                                try
                                {
                                    printList<User>(entityService.UsersSearchByName(piece_of_name_to_find));
                                }
                                catch (ArgumentNullException e)
                                {
                                    Console.WriteLine(e.Message + " Press any button to continue");
                                    Console.ReadLine();
                                    
                                }                                   
                            }
                            else if (user_search_choice == 2)
                            {
                                Console.WriteLine("Type name or part of passport ID to find");
                                string piece_of_password_to_find = Console.ReadLine();
                                try
                                {
                                    printList<User>(entityService.UsersSearchByPassportID(piece_of_password_to_find));
                                }
                                catch (ArgumentNullException e)
                                {
                                    Console.WriteLine(e.Message + " Press any button to continue");
                                    Console.ReadLine();
                                }
                            }
                            int user_id = 0;
                            int book_id = 0;
                            if (action_choice == 1)
                            {
                                Console.WriteLine("Type user id that you want to give a book");
                                 user_id = Int32.Parse(Console.ReadLine());

                                printList<Publication>(entityService.GetAvailablePublications());
                                Console.WriteLine("Type book id you want to give to user");
                                book_id = Int32.Parse(Console.ReadLine());
                                try
                                {
                                    entityService.GiveBookToUser(book_id, user_id);
                                }
                                catch(ArgumentException e)
                                {
                                    Console.WriteLine(e.Message + "Press any key to continue");
                                    Console.ReadLine();

                                }
                            }
                            if (action_choice == 2)
                            {
                                Console.WriteLine("Type user id that want to return the book");
                                user_id = Int32.Parse(Console.ReadLine());

                                try
                                {
                                    printList<Publication>(entityService.GetDebtingPublicationByUserId(user_id));
                                }
                                
                                catch (ArgumentNullException e)
                                {
                                    Console.WriteLine(e.Message + "Press any key to continue");
                                    Console.ReadLine();

                                }
                                Console.WriteLine("Type book id you he want to return");
                                book_id = Int32.Parse(Console.ReadLine());
                                try
                                {
                                    entityService.ReturnBookToLibrary(book_id, user_id);
                                }
                                catch (ArgumentException e)
                                {
                                    Console.WriteLine(e.Message + "Press any key to continue");
                                    Console.ReadLine();
                                }
                            }


                            break;
                        }
                
                    case 4:
                        {
                            entityService.save();
                            flag = false;
                            break;
                        }
                }
            }
            

        }
    }
}
