﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using PresentationLayer;
using DataLayer;
using BusinessLayer;
using System.Collections.Generic;
using System.Text.Json;
using System.IO;
using System;
namespace UnitTestProject
{
    [TestClass]
    public class UnitTestEntity
    {

        [TestMethod]
        public void UserCompareByFirstName()
        {
            string first_name1 = "Dima";
            string first_name2 = "Kima";
            string last_name = "Klymiuk";
            int age = 20;
            string passportId = "AA123456";
            string academicGroup = "scientist";
            User user1 = new User(first_name1, last_name, age, passportId, academicGroup);
            User user2 = new User(first_name2, last_name, age, passportId, academicGroup);
            int expected_value = -1;
            int real_value = User.CompareByFirstName(user1, user2);
            int id = EntityContext<User>.ReadLastIdFromFileInt("User");
            EntityContext<User>.UpdateLastIdInFile("User", id - 2);
            Assert.AreEqual(expected_value, real_value);
        }

        [TestMethod]
        public void UserCompareByLastName()
        {
            string first_name = "Dima";
            string last_name1 = "Petiv";
            string last_name2 = "Klymiuk";

            int age = 20;
            string passportId = "AA123456";
            string academicGroup = "scientist";
            User user1 = new User(first_name, last_name1, age, passportId, academicGroup);
            User user2 = new User(first_name, last_name2, age, passportId, academicGroup);
            int expected_value = 1;
            int real_value = User.CompareByLastName(user1, user2);
            int id = EntityContext<User>.ReadLastIdFromFileInt("User");
            EntityContext<User>.UpdateLastIdInFile("User", id - 2);
            Assert.AreEqual(expected_value, real_value);
        }
        [TestMethod]
        public void UserEquals()
        {
            string first_name1 = "Dima";
            string first_name2 = "Dima";
            string last_name1 = "Petiv";
            string last_name2 = "Klymiuk";

            int age1 = 20;
            int age2 = 20;
            string passportId = "AA123456";
            string academicGroup = "scientist";
            User user1 = new User(first_name1, last_name1, age1, passportId, academicGroup);
            User user2 = new User(first_name2, last_name2, age1, passportId, academicGroup);
            bool expected_value = true;
            bool real_value = user1.Equals(user2);
            int id = EntityContext<User>.ReadLastIdFromFileInt("User");
            EntityContext<User>.UpdateLastIdInFile("User", id - 2);
            Assert.AreEqual(expected_value, real_value);
        }
        [TestMethod]
        public void UserCompareByAcademicGroup()
        {
            string first_name1 = "Dima";
            string first_name2 = "Dima";
            string last_name1 = "Petiv";
            string last_name2 = "Klymiuk";

            int age = 20;
            string passportId1 = "AA123456";
            string passportId2 = "AA123457";
            string academicGroup = "scientist";
            User user1 = new User(first_name1, last_name1, age, passportId1, academicGroup);
            User user2 = new User(first_name1, last_name2, age, passportId1, academicGroup);
            int expected_value = 0;
            int real_value = User.CompareByAcademicGroup(user1, user2);
            int id = EntityContext<User>.ReadLastIdFromFileInt("User");
            EntityContext<User>.UpdateLastIdInFile("User", id - 2);
            Assert.AreEqual(expected_value, real_value);
        }
        [TestMethod]
        public void PublicationCompareByTitle()
        {
            string title1 = "Atitle 1";
            string title2 = "Btitle 2";
            string author2 = "Author 1";
            string author1 = "Author 2";
            string type1 = "Author 2";
            string type2 = "Author 2";


            Publication publication1 = new Publication(title1, author1, type1);
            Publication publication2 = new Publication(title2, author2, type2);
            int expected_value = -1;
            int real_value = Publication.CompareByTitle(publication1, publication2);
            int id = EntityContext<Publication>.ReadLastIdFromFileInt("Publication");
            EntityContext<Publication>.UpdateLastIdInFile("Publication", id - 2);
            Assert.AreEqual(expected_value, real_value);
        }
        [TestMethod]
        public void PublicationCompareByAuthorEqual()
        {
            string title1 = "Atitle 1";
            string title2 = "Btitle 2";
            string author2 = "Author 1";
            string author1 = "Author 1";
            string type1 = "Book";
            string type2 = "Document";


            Publication publication1 = new Publication(title1, author1, type1);
            Publication publication2 = new Publication(title2, author2, type2);
            int expected_value = 0;
            int real_value = Publication.CompareByAuthor(publication1, publication2);
            int id = EntityContext<Publication>.ReadLastIdFromFileInt("Publication");
            EntityContext<Publication>.UpdateLastIdInFile("Publication", id - 2);
            Assert.AreEqual(expected_value, real_value);
        }
        [TestMethod]
        public void PublicationCompareByAuthorDifferent()
        {
            string title1 = "Atitle 1";
            string title2 = "Btitle 2";
            string author1 = "Author1";
            string author2 = "Author2";
            string type1 = "Book";
            string type2 = "Document";
            Publication publication1 = new Publication(title1, author1, type1);
            Publication publication2 = new Publication(title2, author2, type2);
            int expected_value = -1;
            int real_value = Publication.CompareByAuthor(publication1, publication2);
            int id = EntityContext<Publication>.ReadLastIdFromFileInt("Publication");
            EntityContext<Publication>.UpdateLastIdInFile("Publication", id - 2);
            Assert.AreEqual(expected_value, real_value);
        }
        [TestMethod]
        public void User_ToString_Should_ReturnStringRepresentationOfUser()
        {
            string first_name1 = "Dima";
            string last_name1 = "Petiv";
            int age1 = 20;
            string passportId = "AA123456";
            string academicGroup = "scientist";
            User user1 = new User(first_name1, last_name1, age1, passportId, academicGroup);
            string str = user1.ToString();
            int expected_value =0 ;
            int real_value = str.Length;
            int id = EntityContext<User>.ReadLastIdFromFileInt("User");
            EntityContext<User>.UpdateLastIdInFile("User", id - 1);
            Assert.AreNotEqual(expected_value, real_value);
        }
        [TestMethod]
        public void Publication_ToString_Should_ReturnStringRepresentationOfPublciationWithAvailability()
        {
            string title1 = "Atitle 1";           
            string author1 = "Author1";
            string type1 = "Book";
            Publication publication1 = new Publication(title1, author1, type1);
            string str = publication1.toAvailableSring();
            int expected_value = 0;
            int real_value = str.Length;
            int id = EntityContext<Publication>.ReadLastIdFromFileInt("Publication");
            EntityContext<Publication>.UpdateLastIdInFile("Publication", id - 1);
            Assert.AreNotEqual(expected_value, real_value);
        }
        [TestMethod]
        public void Publication_ToString_Should_ReturnStringRepresentationOfPublciationWithoutAvailability()
        {
            string title1 = "Atitle 1";
            string author1 = "Author1";
            string type1 = "Book";
            Publication publication1 = new Publication(title1, author1, type1);
            string str = publication1.ToString();
            int expected_value = 0;
            int real_value = str.Length;
            int id = EntityContext<Publication>.ReadLastIdFromFileInt("Publication");
            EntityContext<Publication>.UpdateLastIdInFile("Publication", id - 1);
            Assert.AreNotEqual(expected_value, real_value);
        }
        [TestMethod]
        public void IssuarenceHistoryConstuctorCheckWithoutId()
        {
            IssuarenceHistory story = new IssuarenceHistory(1, 2, true, true);
        }
        [TestMethod]
        public void IssuarenceHistoryConstuctorCheckWithId()
        {
            IssuarenceHistory story = new IssuarenceHistory(1, 2, true, false);
            EntityContext<IssuarenceHistory>.UpdateLastIdInFile(story.GetType().Name, story.Id-1);
        }
    }
}
