﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using PresentationLayer;
using DataLayer;
using BusinessLayer;
using System.Collections.Generic;
using System.Text.Json;
using System.IO;
using System;
namespace UnitTestProject
{
    [TestClass]
    public class UnitTestEntityService
    {
        
        [TestMethod]
        public void UserConstructor_Should_LeaveLastIdAsItWasBeforeCreatingTestUser()
        {
            int expected_last_id = EntityContext<User>.ReadLastIdFromFileInt("User");
            string first_name = "Dima";
            string last_name = "Klymiuk";
            int age = 20;
            string passportId = "AA123456";
            string academicGroup = "scientist";
            int real_last_id;
            using (User user = new User(first_name, last_name, age, passportId, academicGroup,false))
            real_last_id = EntityContext<User>.ReadLastIdFromFileInt("User");
            Assert.AreEqual(expected_last_id, real_last_id);
        }
        [TestMethod]
        public void Save_Should_SaveAllUsersToFile()
        {
            EntityService entityService = new EntityService();
            int expected_last_id = EntityContext<User>.ReadLastIdFromFileInt("User");
            string first_name = "Tempfirstname";
            string last_name = "Templastname";
            int age = 20;
            string passportId = "PP000000";
            string academicGroup = "scientist";
            User user = new User(first_name, last_name, age, passportId, academicGroup, true);
            int expected = entityService.UsersList.Count + 1;
            entityService.AddUser(user);
            int actual = entityService.UsersList.Count;
            entityService.RemoveLastUser();
            EntityContext<User>.UpdateLastIdInFile("User", expected_last_id);
            entityService.save();
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void Save_Should_SaveAllPublicationToFile()
        {
            EntityService entityService = new EntityService();
            int expected_last_id = EntityContext<Publication>.ReadLastIdFromFileInt("Publication");
            string title = "Title";
            string author = "Author";
            string type = "Book";
            Publication publication = new Publication(title, author, type,true);
            int expected = entityService.PublicationsList.Count + 1;
            entityService.AddPublication(publication);
            int actual = entityService.PublicationsList.Count;
            entityService.RemoveLastPublication();
            EntityContext<Publication>.UpdateLastIdInFile("Publication", expected_last_id);
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GiveBookToUser_Should_ThrowException_When_IndexNotExists()
        {
            EntityService entityService = new EntityService();
            entityService.GiveBookToUser(1, 100);
        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GiveBookToUser_Should_ThrowException_When_PublciationNotExists()
        {
            EntityService entityService = new EntityService();
            entityService.GiveBookToUser(100, 2);
        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ReturnBookToLibrary_Should_ThrowException_When_IndexeAreNotExist1()
        {
            int pub_id = 1;
            int user_id = 200;
            EntityService entityService = new EntityService();
            IssuarenceHistory story = new IssuarenceHistory(pub_id, user_id, true);
            Publication publication = entityService.GetPublicationById(pub_id);
            User user = entityService.GetUserById(user_id);
            user.IssuedPublicationNumber--;
            publication.IsAvailable = true;
            entityService.IssuarenceHistoriesList.Add(story);
            entityService.save();
        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ReturnBookToLibrary_Should_ThrowException_When_IndexeAreNotExist2()
        {
            int pub_id = 4;
            int user_id = 200;
            EntityService entityService = new EntityService();
            IssuarenceHistory story = new IssuarenceHistory(pub_id, user_id, true);
            Publication publication = entityService.GetPublicationById(pub_id);
            User user = entityService.GetUserById(user_id);
            user.IssuedPublicationNumber--;
            publication.IsAvailable = true;
            entityService.IssuarenceHistoriesList.Add(story);
            entityService.save();
        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void RemoveUserById_Should_ThrowException()
        {
            int user_id = 200;
            EntityService entityService = new EntityService();
            entityService.RemoveUserById(user_id);
        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ReturnBookToLibrary_Should_ThrowException1()
        {
            int user_id = 200;
            EntityService entityService = new EntityService();
            entityService.ReturnBookToLibrary(2,user_id);
        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ReturnBookToLibrary_Should_ThrowException2()
        {
            int user_id = 2;
            EntityService entityService = new EntityService();
            entityService.ReturnBookToLibrary(100, user_id);
        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void RemovePublicationById_Should_ThrowException2()
        {
            int pub_id = 200;
            EntityService entityService = new EntityService();
            entityService.RemovePublicationById(pub_id);
        }
        [TestMethod]      
        public void UsersSearchByName_Should_ReturnEmptyList_When_MatchWasntOccured()
        {
            EntityService entityService = new EntityService();
            List<User> users = entityService.UsersSearchByName("292910");
            int expected = 0;
            int actual = users.Count;
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void UsersSearchByPasswordId_Should_ReturnEmptyList_When_MatchWasntOccured()
        {
            EntityService entityService = new EntityService();
            List<User> users = entityService.UsersSearchByPassportID("292910");
            int expected = 0;
            int actual = users.Count;
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetDebtingPublicationsByUserId_Should_ThrowExeption()
        {
            EntityService entityService = new EntityService();
            List<Publication> users = entityService.GetDebtingPublicationByUserId(300);
            
        }
        [TestMethod]
        public void PublicationSearchByKeyWord_Should_ReturnEmptyList()
        {
            EntityService entityService = new EntityService();
            List<Publication> publications = entityService.PublicationSearchByKeyWord("18837");
            int expected = 0;
            int actual = publications.Count;
            Assert.AreEqual(expected, actual);

        }
        [TestMethod]
        public void PublicationSearchByTitle_Should_ReturnEmptyList()
        {
            EntityService entityService = new EntityService();
            List<Publication> publications = entityService.PublicationSearchByTitle("18837");
            int expected = 0;
            int actual = publications.Count;
            Assert.AreEqual(expected, actual);

        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetTakenPublicationForAllTimeByUserId_Should_ThrowExeption()
        {
            EntityService entityService = new EntityService();
            List<Publication> users = entityService.GetTakenPublicationForAllTimeByUserId(300);

        }
        [TestMethod]
        public void GetAvailablePublication_Should_ReturnListOfAvailablePublication()
        {
            EntityService entityService = new EntityService();
            List<Publication> publications = entityService.GetAvailablePublications();
            int expected = 0;
            int actual = publications.Count;
            Assert.AreNotEqual(expected, actual);
        }
        [TestMethod]
        public void PublicationSortByAuthor_Should_ReturnSortedList()
        {
            EntityService entityService = new EntityService();
            List<Publication> publications = entityService.PublicationSortByAuthor();
            int expected = 0;
            int actual = publications.Count;
            Assert.AreNotEqual(expected, actual);
        }
        [TestMethod]
        public void PublicationSortByTitle_Should_ReturnSortedList()
        {
            EntityService entityService = new EntityService();
            List<Publication> publications = entityService.PublicationSortByTitle();
            int expected = 0;
            int actual = publications.Count;
            Assert.AreNotEqual(expected, actual);
        }
        [TestMethod]
        public void UsersSortByFirstName_Should_ReturnSortedList()
        {
            EntityService entityService = new EntityService();
            List<User> users = entityService.UsersSortByFirstName();
            int expected = 0;
            int actual = users.Count;
            Assert.AreNotEqual(expected, actual);
        }
        [TestMethod]
        public void UsersSortByLastName_Should_ReturnSortedList()
        {
            EntityService entityService = new EntityService();
            List<User> users = entityService.UsersSortByLastName();
            int expected = 0;
            int actual = users.Count;
            Assert.AreNotEqual(expected, actual);
        }
        [TestMethod]
        public void UsersSortByAcademicGroup_Should_ReturnSortedList()
        {
            EntityService entityService = new EntityService();
            List<User> users = entityService.UsersSortByAcademicGroup();
            int expected = 0;
            int actual = users.Count;
            Assert.AreNotEqual(expected, actual);
        }


    }
}
