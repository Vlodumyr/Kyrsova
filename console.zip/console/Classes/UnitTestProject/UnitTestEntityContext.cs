using Microsoft.VisualStudio.TestTools.UnitTesting;
using PresentationLayer;
using DataLayer;
using BusinessLayer;
using System.Collections.Generic;
using System.Text.Json;
using System.IO;
namespace UnitTestProject
{
    [TestClass]
    public class UnitTestEntityContext
    {
      
        [TestMethod]
        public void GetFilePath_Should_GetFilepathAccordingToType()
        {
            string dir_path = @"E:\oop\work\console\Classes\DataLayer\Repository\";
            string user_file_path = "users.json";
            string pubication_file_path = "publication.json";
            string issuarence_history_file_path = "issuarence_history.json";
           
            string test_path = EntityContext<User>.GetFilePath();
            StringAssert.Equals(dir_path + user_file_path, test_path);
            test_path = EntityContext<Publication>.GetFilePath();
            StringAssert.Equals(dir_path + pubication_file_path, test_path);
            test_path = EntityContext<IssuarenceHistory>.GetFilePath();
            StringAssert.Equals(dir_path + issuarence_history_file_path, test_path);
        }
        [TestMethod]
        public void AddUser_Should_CreateUserWithIdIncreasedBy1()
        {
            EntityContext<User> entityContext = new EntityContext<User>();
            int expected_id = EntityContext<User>.ReadLastIdFromFileInt("User") + 1;
            EntityContext<User>.UpdateLastIdInFile("User", expected_id);
            int test_id = EntityContext<User>.ReadLastIdFromFileInt("User");
            EntityContext<User>.UpdateLastIdInFile("User", expected_id-1);
            Assert.AreEqual(expected_id, test_id);
        }
        [TestMethod]
        public void CreateFile_Should_CreateFile()
        {
            EntityContext<User> entityContext = new EntityContext<User>();
            entityContext.CreateFile();
            bool actual = File.Exists(entityContext.Path);
            bool expected = true;
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        [ExpectedException(typeof(DirectoryNotFoundException))]
        public void CreateFile_Should_ThrowException()
        {
            File.Create("/somefolder/somefile.txt").Close();
        }

    }
}
