﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using PresentationLayer;
using DataLayer;
using BusinessLayer;
using System.Collections.Generic;
using System.Text.Json;
using System.IO;
using System;
namespace UnitTestProject
{
    [TestClass]
    public class UnitTestRegex
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void UserConstructor_Should_ThrowArgumentExeption_Name()
        {
            string first_name = "Dima";
            string last_name = "klumiUK";
            int age = 20;
            string passportId = "AA123456";
            string academicGroup = "scientist";
            User user = new User(first_name, last_name, age, passportId, academicGroup,true); 
        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void UserConstructor_Should_ThrowArgumentExeption_PassportId()
        {
            string first_name = "Dima";
            string last_name = "Klymiuk";
            int age = 20;
            string passportId = "AA1234568";
            string academicGroup = "scientist";
            User user = new User(first_name, last_name, age, passportId, academicGroup, true);
        }
        [TestMethod]
        public void NameMathch_Should_ReturnBoolIfMatchOccured()
        {
            string first_name = "Dima";
            string last_name = "Klymiuk";
            int age = 20;
            string passportId = "AA123456";
            string academicGroup = "scientist";
            bool real_value;
            using (User user = new User(first_name, last_name, age, passportId, academicGroup))
            {
                real_value = user.NameMatch("D");
            }
            
            bool expected_value = true;
            Assert.AreEqual(expected_value, real_value);
        }
        [TestMethod]
        public void PassportId_Should_ReturnBoolIfMatchOccured()
        {
            string first_name = "Dima";
            string last_name = "Klymiuk";
            int age = 20;
            string passportId = "AA123456";
            string academicGroup = "scientist";
            bool real_value;
            bool expected_value = true;
            using (User user = new User(first_name, last_name, age, passportId, academicGroup))
            {
                real_value = user.PassportIdMatch("A");
            }
            
            Assert.AreEqual(expected_value, real_value);
        }

    }
}
