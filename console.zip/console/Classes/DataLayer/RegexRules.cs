﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace DataLayer
{
    public class RegexRules
    {
        public static bool CheckName(string first_name)
        {
            string regex_str = @"(^\b[A-Z][a-z]+[^0-9]\b$)";
            Regex regex = new Regex(regex_str);
            return regex.IsMatch(first_name);
        }
        public static bool CheckPassportId(string passport_id)
        {
            string regex_str = @"(^\b[A-Z]{2}[\d]{6}\b$)";
            Regex regex = new Regex(regex_str);
            return regex.IsMatch(passport_id);
        }
    }
}
