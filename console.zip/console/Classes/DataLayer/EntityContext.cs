﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Text.Json;
using System.Linq;

namespace DataLayer
{
    public interface IEntity
    {
        public int Id { get; set; }
    }

    public class EntityContext<T>
    {
        public string Path;

        private static string BasePath = @"C:\Users\Gamer\Desktop\console\Classes\DataLayer\Repository\";

        public void CreateFile()
        {
            if (!File.Exists(Path))
            {
                File.Create(Path).Close();
            }
        }
        public void WriteToFile(List<T> data)
        {
            using (StreamWriter streamWriter = new StreamWriter(Path))
            {
                string JsonText;
                JsonSerializerOptions options = new JsonSerializerOptions();
                options.WriteIndented = true;
                JsonText = JsonSerializer.Serialize<List<T>>(data, options);
                //TODO:: throw exeption if Json is empty;
                streamWriter.WriteLine(JsonText);
            }
        }
        public List<T> ReadFromFile()
        {
            List<T> return_list = new List<T>();
            using (StreamReader streamReader = new StreamReader(Path))
            {
                JsonSerializerOptions options = new JsonSerializerOptions();
                options.WriteIndented = true;
                string JsonText;
                JsonText = streamReader.ReadToEnd();
                if (JsonText != "")
                {
                    return_list = JsonSerializer.Deserialize<List<T>>(JsonText, options);
                }
            }
            return return_list;
        }
        public static int ReadLastIdFromFileInt(string class_name)
        {

            Dictionary<string, int> return_dict = new Dictionary<string, int>();
            string path = @"C:\Users\Gamer\Desktop\console\Classes\DataLayer\Repository\last_id.json";
            int return_id = 0;
            using (StreamReader streamReader = new StreamReader(path))
            {

                string JsonText;
                JsonText = streamReader.ReadToEnd();
                return_dict = JsonSerializer.Deserialize<Dictionary<string, int>>(JsonText);
                return_id = return_dict[class_name];
                //TODO:: throw exeption if Json is empty;
            }
            return return_id;
        }
        public static List<T> ReadLastIdFromFileDict()
        {
            var path = System.IO.Path.Combine(BasePath, $"{typeof(T).Name}.json");
            return JsonSerializer.Deserialize<List<T>>(File.ReadAllText(path));

        
        }

        public static void Update(int id)
        {
            var path = System.IO.Path.Combine(BasePath, $"{typeof(T).Name}.json");

            var dictionary = ReadLastIdFromFileDict();

            var item = dictionary.LastOrDefault();

            if (item is IEntity entity)
                entity.Id = id;


            var serializeObject = JsonSerializer.Serialize(dictionary);

            File.WriteAllText(path, serializeObject);
        }

        public static void UpdateLastIdInFile(string className, int id)
        {
            var path = System.IO.Path.Combine(BasePath, $"{typeof(T).Name}.json");

            var dictionary = ReadLastIdFromFileDict();

            var item = dictionary.LastOrDefault();

            if (item is IEntity entity)
                entity.Id = id;


            var serializeObject = JsonSerializer.Serialize(dictionary);

            File.WriteAllText(path, serializeObject);

        }
        public static string GetFilePath()
        {

            return System.IO.Path.Combine(BasePath, $"{typeof(T).Name}.json");

        }
        public EntityContext()
        {
            Path = GetFilePath();
        }

    }
}
