﻿using System.Text;
using DataLayer;
using System.Collections.Generic;
using System;

namespace BusinessLayer
{
    public class EntityService
    {
        static private string dir_path = @"E:\oop\work\console\Classes\DataLayer\Repository\";
        static private string user_file_path = "users.json";
        static private string pubication_file_path = "publication.json";
        static private string issuarence_history_file_path = "issuarence_history.json";

        public List<User> UsersList { get; private set; }
        public List<Publication> PublicationsList { get; private set; }
        public List<IssuarenceHistory> IssuarenceHistoriesList { get; private set; }
        private EntityContext<User> users_entity;
        private EntityContext<Publication> publication_entity;
        private EntityContext<IssuarenceHistory> issuarence_history_entity;
        public void save()
        {
            users_entity.WriteToFile(UsersList);
            publication_entity.WriteToFile(PublicationsList);
            issuarence_history_entity.WriteToFile(IssuarenceHistoriesList);
        }
        public EntityService()
        {
            users_entity = new EntityContext<User>();
            users_entity.CreateFile();
            UsersList = users_entity.ReadFromFile();
            if (UsersList.Count > 1)
            {
                EntityContext<User>.UpdateLastIdInFile("User", UsersList[UsersList.Count - 1].Id);
            }
            publication_entity = new EntityContext<Publication>();
            publication_entity.CreateFile();
            PublicationsList = publication_entity.ReadFromFile();
            if (PublicationsList.Count > 1)
            {
                //EntityContext<Publication>.UpdateLastIdInFile("Publication", PublicationsList[PublicationsList.Count - 1].Id);

                EntityContext<Publication>.Update(25);
            }

            issuarence_history_entity = new EntityContext<IssuarenceHistory>();
            issuarence_history_entity.CreateFile();
            IssuarenceHistoriesList = issuarence_history_entity.ReadFromFile();
            if (IssuarenceHistoriesList.Count > 1)
            {
                EntityContext<IssuarenceHistory>.UpdateLastIdInFile("IssuarenceHistory", IssuarenceHistoriesList[IssuarenceHistoriesList.Count - 1].Id);
            }
        }

        public void AddUser(User user)
        {
            UsersList.Add(user);
            users_entity.WriteToFile(UsersList);
        }
        public void AddPublication(Publication publication)
        {
            PublicationsList.Add(publication);
            publication_entity.WriteToFile(PublicationsList);
            if (!publication.GetIsTest)
            {
                IssuarenceHistory story = new IssuarenceHistory(publication.Id);
                IssuarenceHistoriesList.Add(story);
                issuarence_history_entity.WriteToFile(IssuarenceHistoriesList);
            }
        }
        public void GiveBookToUser(int pub_id, int user_id)
        {
            IssuarenceHistory story = new IssuarenceHistory(pub_id, user_id, false);
            Publication publication = this.GetPublicationById(pub_id);
            if (publication.IsAvailable == false)
            {
                throw new ArgumentException("Book that you want to give isn't in library");
            }
            User user = this.GetUserById(user_id);
            user.IssuedPublicationNumber++;

            publication.IsAvailable = false;
            IssuarenceHistoriesList.Add(story);
            this.save();
        }
        public void ReturnBookToLibrary(int pub_id, int user_id)
        {
            IssuarenceHistory story = new IssuarenceHistory(pub_id, user_id, true);
            Publication publication = this.GetPublicationById(pub_id);
            User user = this.GetUserById(user_id);
            user.IssuedPublicationNumber--;
            publication.IsAvailable = true;
            IssuarenceHistoriesList.Add(story);
            this.save();
        }
        public void RemoveLastUser()
        {
            UsersList.RemoveAt(UsersList.Count - 1);
            users_entity.WriteToFile(UsersList);
        }
        public void RemoveUserById(int id)
        {
            int index = UsersList.FindIndex(0, UsersList.Count - 1, (x) => x.Id == id);
            if (index == -1)
            {
                throw new ArgumentException("There is no user with this id. Please select from given id`s.");
            }
            UsersList.RemoveAt(index);
            users_entity.WriteToFile(UsersList);
        }
        public void RemovePublicationById(int id)
        {
            int index = PublicationsList.FindIndex(0, PublicationsList.Count - 1, (x) => x.Id == id);
            if (index == -1)
            {
                throw new ArgumentException("There is no user with this id. Please select from given id`s.");
            }
            PublicationsList.RemoveAt(index);
            publication_entity.WriteToFile(PublicationsList);
        }
        public void RemoveLastPublication()
        {
            PublicationsList.RemoveAt(PublicationsList.Count - 1);
            publication_entity.WriteToFile(PublicationsList);
        }
        public List<User> UsersSearchByName(string str)
        {
            return UsersList.FindAll((x) => x.NameMatch(str));
        }
        public List<Publication> PublicationSearchByKeyWord(string str)
        {
            return PublicationsList.FindAll((x) => x.KeyWordMatch(str));
        }
        public List<Publication> PublicationSearchByTitle(string str)
        {
            return PublicationsList.FindAll((x) => x.TitleMatch(str));
        }
        public List<User> UsersSearchByPassportID(string str)
        {
            return UsersList.FindAll((x) => x.PassportIdMatch(str));
        }
        public User GetUserById(int id)
        {
            User user = UsersList.Find((x) => x.Id == id);
            if (user == null)
            {
                throw new ArgumentNullException("This ID doesn't exist. Please select from given ID`s");
            }
            return user;
        }
        public Publication GetPublicationById(int id)
        {
            Publication publication = PublicationsList.Find((x) => x.Id == id);
            if (publication == null)
            {
                throw new ArgumentNullException("There is no publication with that id. Please select from giving list");
            }
            return publication;
        }
        public List<User> UsersSortByFirstName()
        {
            List<User> sortedList = new List<User>(UsersList);
            sortedList.Sort((x, y) => User.CompareByFirstName(x, y));
            return sortedList;
        }
        public List<User> UsersSortByLastName()
        {
            List<User> sortedList = new List<User>(UsersList);
            sortedList.Sort((x, y) => User.CompareByLastName(x, y));
            return sortedList;
        }
        public List<User> UsersSortByAcademicGroup()
        {
            List<User> sortedList = new List<User>(UsersList);
            sortedList.Sort((x, y) => User.CompareByAcademicGroup(x, y));
            return sortedList;
        }
        public List<Publication> PublicationSortByTitle()
        {
            List<Publication> sortedList = new List<Publication>(PublicationsList);
            sortedList.Sort((x, y) => Publication.CompareByTitle(x, y));
            return sortedList;
        }
        public List<Publication> PublicationSortByAuthor()
        {
            List<Publication> sortedList = new List<Publication>(PublicationsList);
            sortedList.Sort((x, y) => Publication.CompareByAuthor(x, y));
            return sortedList;
        }
        public List<Publication> GetAvailablePublications()
        {
            List<Publication> stories_list = PublicationsList.FindAll((x) => x.IsAvailable == true);
            if (stories_list.Count == 0)
            {
                throw new ArgumentNullException("There is no available publications");
            }
            return stories_list;
        }
        public List<Publication> GetDebtingPublicationByUserId(int user_id)
        {
            List<IssuarenceHistory> stories_list = IssuarenceHistoriesList.FindAll((x) => x.UserId == user_id);
            if (stories_list.Count == 0)
            {
                throw new ArgumentNullException("This Id doen't exist. Please enter id from given list");
            }
            List<Publication> return_publication_list = new List<Publication>();
            foreach (IssuarenceHistory story in stories_list)
            {
                Publication publication = this.GetPublicationById(story.PublicationId);
                if (publication.IsAvailable == false)
                {
                    return_publication_list.Add(publication);
                }

            }
            return return_publication_list;
        }
        public List<Publication> GetTakenPublicationForAllTimeByUserId(int user_id)
        {
            List<IssuarenceHistory> stories_list = IssuarenceHistoriesList.FindAll((x) => x.UserId == user_id);
            if (stories_list.Count == 0)
            {
                throw new ArgumentNullException("This Id doen't exist. Please enter id from given list");
            }
            List<Publication> return_publication_list = new List<Publication>();
            foreach (IssuarenceHistory story in stories_list)
            {
                Publication publication = this.GetPublicationById(story.PublicationId);
                return_publication_list.Add(publication);
            }
            return return_publication_list;
        }
    }
}
