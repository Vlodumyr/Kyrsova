﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer;
using System.Text.RegularExpressions;
namespace BusinessLayer
{
    [Serializable]
    public class User: IDisposable
    {
        private string firstName;
        private string lastName;
        private string passportId;
        private int issuedPublicationNumber;
        public int Id { get; set; }
        public string FirstName { 
            get
            {
                return firstName;
            }
            set 
            {
                if (RegexRules.CheckName(value))
                {
                    firstName = value;
                }
                else
                {
                    throw new ArgumentException("Invalid first name");
                }
            }
        }
        public string LastName
        {
            get
            {
                return lastName;
            }
            set
            {
                if (RegexRules.CheckName(value))
                {
                    lastName = value;
                }
                else
                {
                    throw new ArgumentException("Invalid last name");
                }
            }
        }
        public int Age { get; set; }
        public string PassportId
        {
            get
            {
                return passportId;
            }
            set
            {
                if (RegexRules.CheckPassportId(value))
                {
                    passportId = value;
                }
                else
                {
                    throw new ArgumentException("Invalid passport Id");
                }
            }
        }
        public string AcademicGroup { get; set; }
        public int IssuedPublicationNumber {
            get
            {
                return issuedPublicationNumber;
            }
            set
            {
                if (value > 5)
                {
                    throw new ArgumentException("Library can't give more that 5 books to one person.");
                }
                else
                {
                    issuedPublicationNumber = value;
                }
            } 
        }

        private bool is_test;
        private bool is_without_id;

        public User(string firstName, string lastName, int age, string passportId, string academicGroup, bool without_id = true, bool is_test = true,  int isssuedPublicationNumber=0)
        {
            //TODO: Create event when adds new user automatically increase last id;
            if (RegexRules.CheckName(firstName))
            {
                this.FirstName = firstName;
            }
            else
            {
                throw new ArgumentException("Invalid first name");
            }
            if (RegexRules.CheckName(lastName))
            {
                this.LastName = lastName;
            }
            else
            {
                throw new ArgumentException("Invalid last name");
            }
            this.Age = age;
            if (RegexRules.CheckPassportId(passportId))
            {
                this.PassportId = passportId;
            }
            else
            {
                throw new ArgumentException("Invalid passportId");
            }
            this.AcademicGroup = academicGroup;
            this.IssuedPublicationNumber = isssuedPublicationNumber;
            //this.Registation_date = DateTime.Now;
            this.is_test = is_test;
            if (without_id)
            {
                int current_id = EntityContext<User>.ReadLastIdFromFileInt(this.GetType().Name);
                this.Id = current_id + 1;
                EntityContext<User>.UpdateLastIdInFile(this.GetType().Name, this.Id);
            }
           
        }
        public User() { }
        ~User()
        {
            Dispose();
        }
        public override string ToString()
        {
            
            int id_length = 3;
            int name_length = 15;
            int passportId_length = 10;
            int group_lenght = 15;
            int age_lenght = 3;
            int pub_lenght = 1;
            string id = this.Id.ToString() + (new String(' ', id_length - this.Id.ToString().Length));
            string firstname = this.FirstName + (new String(' ', name_length - this.FirstName.ToString().Length));
            string lastname = this.LastName + (new String(' ', name_length - this.LastName.ToString().Length));
            string passportId = this.PassportId + (new String(' ', passportId_length - this.PassportId.ToString().Length));
            string age = this.Age + (new String(' ', age_lenght - this.Age.ToString().Length));
            string issuedpub = this.IssuedPublicationNumber + (new String(' ', pub_lenght - this.IssuedPublicationNumber.ToString().Length));
            string group = this.AcademicGroup + (new String(' ', group_lenght - this.AcademicGroup.ToString().Length));
            return String.Format("|{0,2}|{1,1}|{2,1}|{3,1}|{4,1}|{5,1}|{6,1}|", id, firstname, lastname, passportId, age, group, issuedpub);
        }
        public override bool Equals(Object obj)
        {
            return this.PassportId == ((User)obj).PassportId;
        }

        public void Dispose()
        {
            if (this.is_test && this.Id != 0 && this.is_without_id != true)
            {
                EntityContext<User>.UpdateLastIdInFile(this.GetType().Name, this.Id - 1);
                this.Id = 0;
            }
        }
        public bool NameMatch(string str)
        {
            string reg_str = @"^(.*"+str+".*)$";
            Regex regex = new Regex(reg_str);
            return regex.IsMatch(FirstName + " " + LastName);
        }
        public bool PassportIdMatch(string str)
        {
            string reg_str = @"^(.*" + str + ".*)$";
            Regex regex = new Regex(reg_str);
            return regex.IsMatch(PassportId);
        }
        public static int CompareByFirstName(User user1, User user2)
        {
            return user1.FirstName.CompareTo(user2.FirstName); 
        }
        public static int CompareByLastName(User user1, User user2)
        {
            return user1.LastName.CompareTo(user2.LastName);
        }
        public static int CompareByAcademicGroup(User user1, User user2)
        {
            return user1.AcademicGroup.CompareTo(user2.AcademicGroup);
        }
    }
}
