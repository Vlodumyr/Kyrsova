﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer;

namespace BusinessLayer
{
    public class IssuarenceHistory : IDisposable
    {
        public int Id { get; set; }
        public int PublicationId { get; set; }
        public int UserId { get; set; }
        public bool InLibrary { get; set; }
        private bool Is_Test;
        public IssuarenceHistory(int pub_id, int user_id = 0, bool inLibrary = true, bool is_test = true)
        {
            this.PublicationId = pub_id;
            this.UserId = user_id;
            this.InLibrary = inLibrary;
            this.Is_Test = is_test;
            if (!Is_Test)
            {
                int current_id = EntityContext<IssuarenceHistory>.ReadLastIdFromFileInt(this.GetType().Name);
                this.Id = current_id + 1;
                EntityContext<IssuarenceHistory>.UpdateLastIdInFile(this.GetType().Name, this.Id);
            }
           
        }
        public IssuarenceHistory(){}
        public void Dispose()
        {
            if (this.Is_Test && this.Id != 0)
            {
                EntityContext<IssuarenceHistory>.UpdateLastIdInFile(this.GetType().Name, this.Id - 1);
                this.Id = 0;
            }
        }
        ~IssuarenceHistory()
        {
            Dispose();
        }
    }

        
}

