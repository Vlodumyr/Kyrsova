﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using DataLayer;




namespace BusinessLayer
{

    

    public class Publication : IEntity, IDisposable
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string PublicationType { get; set; }
        public bool IsAvailable { get; set; }
        [NonSerialized]
        private bool Is_test;
        public bool GetIsTest { get => Is_test; }
        public Publication() { }
        public Publication(string title, string author, string type, bool is_test = true)
        {
            this.Title = title;
            this.Author = author;
            this.PublicationType = type;
            this.Is_test = is_test;
            this.IsAvailable = true;
            int current_id = EntityContext<Publication>.ReadLastIdFromFileInt(this.GetType().Name);
            this.Id = current_id + 1;
            EntityContext<Publication>.UpdateLastIdInFile(this.GetType().Name, this.Id);
        }
        public bool KeyWordMatch(string str)
        {
            string reg_str = @"^(.*" + str + ".*)$";
            Regex regex = new Regex(reg_str);
            return regex.IsMatch(this.Title + " " + this.Author);
        }
        public bool TitleMatch(string str)
        {
            string reg_str = @"^(.*" + str + ".*)$";
            Regex regex = new Regex(reg_str);
            return regex.IsMatch(this.Title);
        }
        ~Publication()
        {
            Dispose();
        }
        public void Dispose()
        {
            if (this.Is_test && this.Id != 0)
            {
                EntityContext<Publication>.UpdateLastIdInFile(this.GetType().Name, this.Id - 1);
                this.Id = 0;
            }
        }
        public override string ToString()
        {
            int id_length = 2;
            int title_length = 30;
            int author_length = 30;
            int pub_type_length = 10;
            string id = this.Id.ToString() + (new String(' ', id_length - this.Id.ToString().Length));
            string title = this.Title + (new String(' ', title_length - this.Title.ToString().Length));
            string author = this.Author + (new String(' ', author_length - this.Author.ToString().Length));
            string pub_type = this.PublicationType + (new String(' ', pub_type_length - this.PublicationType.ToString().Length));
            return String.Format("|{0,2}|{1,1}|{2,1}|{3,1}|", id, title, author, pub_type);
        }
        public string toAvailableSring()
        {
            int id_length = 2;
            int title_length = 30;
            int author_length = 30;
            int pub_type_length = 10;
            string id = this.Id.ToString() + (new String(' ', id_length - this.Id.ToString().Length));
            string title = this.Title + (new String(' ', title_length - this.Title.ToString().Length));
            string author = this.Author + (new String(' ', author_length - this.Author.ToString().Length));
            string pub_type = this.PublicationType + (new String(' ', pub_type_length - this.PublicationType.ToString().Length));
            string availebiliti_str = this.IsAvailable == true ? "Yes" : "No";
            return String.Format("|{0,2}|{1,1}|{2,1}|{3,1}|{4,1}|", id, title, author, pub_type, availebiliti_str);
        }

        public static int CompareByTitle(Publication pub1, Publication pub2)
        {
            return pub1.Title.CompareTo(pub2.Title);
        }
        public static int CompareByAuthor(Publication pub1, Publication pub2)
        {
            return pub1.Author.CompareTo(pub2.Author);
        }
    }
}
